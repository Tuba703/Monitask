<?php
$con = mysqli_connect('localhost','root','','monitask');
if($con){

}else{
	echo "Not Connected";
}

?>
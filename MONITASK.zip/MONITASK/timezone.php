<?php
	$timezone = 'Asia/Karachi';
	date_default_timezone_set($timezone);
?>
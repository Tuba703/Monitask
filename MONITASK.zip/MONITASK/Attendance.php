<?php
include('db.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!DOCTYPE html>
<html>

<head>
	<title>MONITASK</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	  <link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
    <link rel="stylesheet" href="css/attendance.css">
</head>

<body>
<div class="container">
<h2>Attendance</h2>
<!--****************************************** Take Attendance *************************************************-->
<table>
<thead>
  <tr>
    <th>Emloyee ID</th>
    <th>Name</th>
    <th>Email</th> 
  </tr>
</head>

<tbody>
<?php
$query= "select * from employee";
$result=$con->query($query);
while($show=$result->fetch_assoc()){
?>


  <tr>
    <td><?php echo $show['firstname']?></td>
    <td><?php echo $show['empid']?></td>
    <td>
        Present <input type="radio" name="attendance[<?php echo $show['id']?>]" value="Present">Absent<input type="radio" name="attendance[<?php echo $show['id']?>]" value="Absent" type="text">
    </td>
  </tr>

<?php } ?>
<tbody>

</table>
<br><br>
<input class="btn btn-primary" type="submit" name="submit" value="Mark Attendance" />
<br><br><br>

</div>

</body>
</html>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
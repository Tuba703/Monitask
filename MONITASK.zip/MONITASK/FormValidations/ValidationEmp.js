<script>

function addemp(){

    var name = $('#firstname').val();
    if(name.trim() == ''){
        alert('Please enter your name.');
        $('#firstname').focus();
        return false;
    }

    else{
        $.ajax({
            type:'POST',
            url:'add.php',
            data:'contactFrmSubmit=1&name='+name+'&email='+email+'&message='+message,
            beforeSend: function () {
                $('.submitBtn').attr("disabled","disabled");
                $('.modal-body').css('opacity', '.5');
            },
            success:function(msg){
            }
        });
    }
}
</script>
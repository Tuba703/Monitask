<?php
include('db.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<!DOCTYPE html>
<html>
<head>
	<title>MONITASK</title>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<link rel="stylesheet" href="//cdn.datatables.net/1.10.20/css/jquery.dataTables.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
</head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
<body>
<div class="container">
<h2>Attendance</h2>


<table>
  <tr>
    <th>Emloyee ID</th>
    <th>Name</th>
    <th>Email</th>
    <th>Status/th>
    
  </tr>
  <tr>
    <td>101</td>
    <td>Mahnoor Asim</td>
    <td>mahnoor@gmail.com</td>
    <td>
        <label for="present5">
            <input type="radio" id="present5" name="attendance_status[5]" value="Present"> Present
        </label>
        <label for="absent5">
            <input type="radio" id="absent5" name="attendance_status[5]" value="Absent"> Absent
        </label>
    </td>
  </tr>

  <tr>
    <td>102</td>
    <td>Tuba Saifullah</td>
    <td>tuba@gmail.com</td>
    <td>
        <label for="present5">
            <input type="radio" id="present5" name="attendance_status[5]" value="Present"> Present
        </label>
        <label for="absent5">
            <input type="radio" id="absent5" name="attendance_status[5]" value="Absent"> Absent
        </label>
    </td>
  </tr>

  <tr>
    <td>103</td>
    <td>Ayesha</td>
    <td>ayesha@gmail.com</td>
    <td>
        <label for="present5">
            <input type="radio" id="present5" name="attendance_status[5]" value="Present"> Present
        </label>
        <label for="absent5">
            <input type="radio" id="absent5" name="attendance_status[5]" value="Absent"> Absent
        </label>
    </td>
  </tr>

  <tr>
    <td>104</td>
    <td>Maham</td>
    <td>maham@gmail.com</td>
    <td>
        <label for="present5">
            <input type="radio" id="present5" name="attendance_status[5]" value="Present"> Present
        </label>
        <label for="absent5">
            <input type="radio" id="absent5" name="attendance_status[5]" value="Absent"> Absent
        </label>
    </td>
  </tr>

  <tr>
    <td>105</td>
    <td>Raheem</td>
    <td>raheem@gmail.com</td>
    <td>
        <label for="present5">
            <input type="radio" id="present5" name="attendance_status[5]" value="Present"> Present
        </label>
        <label for="absent5">
            <input type="radio" id="absent5" name="attendance_status[5]" value="Absent"> Absent
        </label>
    </td>
  </tr>

</table>
<br><br>
<input class="btn btn-primary" type="submit" name="submit" value="Mark Attendance" />
<br><br><br>

</div>

</body>
</html>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
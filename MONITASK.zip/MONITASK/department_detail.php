<?php
include('db.php');
include('includes/header.php'); 
include('includes/navbar.php'); 
?>


<?php
require 'db.php';
$a=$_GET['id'];

$detail = "Select * FROM department WHERE department_id = $a";
$run_data = mysqli_query($con,$detail);
$row = mysqli_fetch_assoc($run_data);
$l=$row['location'];
$n=$row['name'];
$d=$row['description'];

?>

<!DOCTYPE html>
<html>
<head>
	<title>MONITASK</title>
</head>
<body>
<div class=container-fluid>
<div class = "content-wrapper">

<!-- Page Heading -->
<div class="d-sm-flex align-items-center justify-content-between mb-4">
   <h1 class="h3 mb-0 text-gray-800">Department Detail </h1>
   <a href="department_List.php" class="d-none d-sm-inline-block btn btn-sm btn-primary shadow-sm"><i 
   class="fas fa-caret-square-right"></i>-</a>
 </div>

</div>	
<hr>
	<h3>Department Name	:  <?php echo $n ?></h3>
	<h3>location		:  <?php echo $l ?></h3>
	<h3>Description		:  <?php echo $d ?></h3>
	<h3>Total Employees	:  <?php  ?></h3>
</div>
</body>
</html>

<?php
include('includes/scripts.php');
include('includes/footer.php');
?>
<?php
include('db.php');
include('includes/header.php'); 
include('includes/navbar.php'); 

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Welcome Employee</h1>
    <?php
require 'db.php';
$a=$_SESSION['username'];
$detail = "SELECT * FROM register WHERE email = '$a' ";

$run_data = mysqli_query($con,$detail);
$row = mysqli_fetch_assoc($run_data);

$n=$row['id'];

?>
<h1>PROFILE</h1>
<h4>Employee Name	 &nbsp :  &nbsp<?php echo $a ?></h4>
<h4>Employee Name	 &nbsp :  &nbsp<?php echo $n ?></h4>
<h1>ATTENDANCE</h1>

</body>
</html>
<?php
include('db.php');
?>

<?php
    $range_to = date('m/d/Y');
    $range_from = date('m/d/Y', strtotime('-30 day', strtotime($range_to)));
?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">    
</head>
<body>

<div class="container-fluid">


 <!-- Page Heading -->
 <div class="box-header with-border">
        <div class="pull-left">
            <input type="text" class="form-control pull-right col-sm-13" id="reservation" name="date_range" value="<?php echo (isset($_GET['range'])) ? $_GET['range'] : $range_from.' - '.$range_to; ?>">&nbsp;
        </div> 
  </div>

<br><br><hr>

		<table class="table table-bordered table-striped table-hover">
		<thead>
			<tr>
                  <th>Employee ID</th>
                  <th>Gross</th>
                  <th>Cash Advance</th>
                  <th>Range</th>
			</tr>
		</thead>
    
    <?php                    
                    $to = date('Y-m-d');
                    $from = date('Y-m-d', strtotime('-30 day', strtotime($to)));

                    if(isset($_GET['range'])){
                      $range = $_GET['range'];
                      $ex = explode(' - ', $range);
                      $from = date('Y-m-d', strtotime($ex[0]));
                      $to = date('Y-m-d', strtotime($ex[1]));
                    }
                  /* *******************Fetch Record From Employee ********************** */
                  $sql = "SELECT * from employee";

                  $query = $con->query($sql);
                  $total = 0;
                  while($row = $query->fetch_assoc()){
                  $empid = $row['id'];
                  /* **************** Cash Advance ********************* */
                      $casql = "SELECT *, SUM(aamount) AS cashamount FROM advance WHERE id='$empid' AND adate BETWEEN '$from' AND '$to'";
                      
                      $caquery = $con->query($casql);
                      $carow = $caquery->fetch_assoc();
                      $cashadvance = $carow['cashamount'];

                      $gross = $row['Salary'] ;

                      
                      echo "
                        <tr>
                          <td>".$row['empid']."</td>
                          <td>".number_format($gross, 2)."</td>
                          <td>".number_format($cashadvance, 2)."</td>
                          <td>".$from."-".$to. "</td>
                        </tr>
                      ";
                  }
                  ?>
		</table>
	</div>


<script>
$(function(){
  $("#reservation").on('change', function(){
    var range = encodeURI($(this).val());
    window.location = 'payrol.php?range='+range;
  });
});
</script>

<!--*************************************Date Range Picker**************************************************************-->

<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script> 
<script src="vendor/jquery/jquery.min.js"></script>
<script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script> 

<script> 
$(function() {
  //Date range picker
  $('#reservation').daterangepicker()

  $('input[name="date_range"]').daterangepicker({
    opens: 'left'
  }, function(start, end, label) {
    console.log("A new date selection was made: " + start.format('YYYY-MM-DD') + ' - ' + end.format('YYYY-MM-DD'));
  });
});
</script>

<script type="text/javascript" src="https://cdn.jsdelivr.net/jquery/latest/jquery.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/momentjs/latest/moment.min.js"></script>
<script type="text/javascript" src="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.min.js"></script>
<link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/daterangepicker/daterangepicker.css" />


</body>
</html>


<?php
$con = mysqli_connect('localhost','root','','card_activation');
if($con){
	
}else{
	echo "Not Connected";
}

?>
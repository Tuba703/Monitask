var database = firebase.database();
//TABLE REFERENCE-----------------------------------------------------------
var empRef = firebase.database().ref('Employee');
var new_html = '';


window.onload = function () {
    displayEmpData();
};



// Save DATA into Attendance Table-------------------------------------------
function SaveEmpAtt() {
    
    var Dte = document.getElementById('dte').value;
    var status = document.getElementsByById('a').value;
    var timein = document.getElementByById('b').value;
    var timeout = document.getElementByById('c').value;
    var overtime = document.getElementByById('d').value;
    database.ref('Attendance/'+Dte).set({
        Date : Dte,
        Status : status,
        Time_in : timein,
        Time_out : timeout,
        Overtime : overtime
    });
}



//Display Employee Data--------------------------------------------------------
function displayEmpData() {

    empRef.on('child_added', function (empData) {
        console.log(empData.val());

        new_html += '<tr id="'+empData.val().emp_id+'">';

        new_html += '<td id="name_'+empData.val().emp_id+'">' + empData.val().name + '</td>';
        
        new_html += '<td ><select option="present/Absent"  id="a" type="time" >';
        new_html += '<option value="present">Present</option>'
        new_html += '<option value="absent">Absent</option>'
        
        new_html += '</select>'
        new_html += '</td>';

        new_html += '<td ><input id="b" type="time" >';
        new_html += '</td>';

        new_html += '<td ><input  id="c" type="time" >';
        new_html += '</td>';

        new_html += '<td ><input id="d" type="time" >';
        new_html += '</td>';

        new_html += '</tr>';

        $("#emp-table").html(new_html);
       
    });


    // $('#emp-table').find('tbody').append(new_html);

}


$(document).on('click', '.editEmp', function () {
    var emp_id = $(this).attr('data-emp-id');
    empRef.child(emp_id).once('value', function (emp) {
        var modal_header = '';

        modal_header += '<h4 class="modal-title">Add ' + emp.val().name + '</h4>';
        modal_header += '<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>';

        var modal_body = '';
        modal_body += '<div class="form-group">';
        modal_body += '<label>Name</label>';
        modal_body += '<input id="edit-name" type="text" value="'+emp.val().name+'" class="form-control" required>';
        modal_body += '</div>';
        modal_body += '<div class="form-group">';
        modal_body += '<label>Email</label>';
        modal_body += '<input type="email" id="edit-email" value="'+emp.val().email+'" class="form-control" required>';
        modal_body += '</div>';
        modal_body += '<div class="form-group">';
        modal_body += '<label>Address</label>';
        modal_body += '<textarea id="edit-address"  class="form-control" required>'+emp.val().address+'</textarea>';
        modal_body += '</div>';
        modal_body += '<div class="form-group">';
        modal_body += '<label>Phone</label>';
        modal_body += '<input id="edit-phone" type="text" value="'+emp.val().phone+'" class="form-control" required>';
        modal_body += '</div>';
        

        var modal_footer = '';
        modal_footer += '<input type="button" class="btn btn-default" data-dismiss="modal" value="Cancel">';
        modal_footer += '<input type="submit" data-dismiss="modal" data-emp-id="'+emp_id+'"  class="btn btn-danger updateEmpData" value="Save">';
        $("#editEmployeeModal").find('.modal-header').html(modal_header);
        $("#editEmployeeModal").find('.modal-body').html(modal_body);
        $("#editEmployeeModal").find('.modal-footer').html(modal_footer);
        $("#editEmployeeModal").modal();
    })
});



$(document).on('click', '.updateEmpData', function () {
    var emp_id = $(this).attr('data-emp-id');
     
    var name = document.getElementById('edit-name').value;
    var email = document.getElementById('edit-email').value;
    var address = document.getElementById('edit-address').value;
    var phone = document.getElementById('edit-phone').value;  
    empRef.child(emp_id).update({
        name: name,
        email: email,
        address: address,
        phone: phone
    });    
    $('#name_'+emp_id).html(name);
    $('#email_'+emp_id).html(email);
    $('#address_'+emp_id).html(address);
    $('#phone_'+emp_id).html(phone);    
});


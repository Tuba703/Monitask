
  // Your web app's Firebase configuration
  // For Firebase JS SDK v7.20.0 and later, measurementId is optional
  var firebaseConfig = {
    apiKey: "AIzaSyA0q0WFD8jzjkGcgB5KlRW4qCkRSNkZ3zw",
    authDomain: "monitask-26b33.firebaseapp.com",
    projectId: "monitask-26b33",
    storageBucket: "monitask-26b33.appspot.com",
    messagingSenderId: "266316968222",
    appId: "1:266316968222:web:98fd4c9cfed10dbc5fd90f",
    measurementId: "G-T76YXDHB97"
  };
  // Initialize Firebase
  firebase.initializeApp(firebaseConfig);

package com.example.employeeattendence.util;

public class Constants {
    public static final String STUDENT = "Student";
    public static final String TEACHER = "Teacher";
    public static final String COURSES = "Courses";
    public static final String ATTENDENCE = "Attendence";


    public static final String NAME = "Name";
    public static final String COURSE = "Course";
    public static final String EMAIL = "Email";
    public static final String TODAY_ATTEND = "todayAttend";
}
